

#import "KeyDataBean.h"

@implementation KeyDataBean

@end
