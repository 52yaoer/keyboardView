

#import <Foundation/Foundation.h>

@interface KeyDataBean : NSObject

@property (nonatomic) NSInteger index;

@property (nonatomic, strong) NSString *idx;

@property (nonatomic, strong) NSString *icon;

@end
