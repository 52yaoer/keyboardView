//
//  main.m
//  UZApp
//
//  Created by kenny on 14-9-13.
//  Copyright (c) 2014年 APICloud. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, @"UZAppDelegate");
    }
}
